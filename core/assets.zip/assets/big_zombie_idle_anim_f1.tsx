<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="big_zombie_idle_anim_f1" tilewidth="32" tileheight="34" tilecount="1" columns="1">
 <image source="big_zombie_idle_anim_f1.png" width="32" height="34"/>
</tileset>
