<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="0x72_DungeonTilesetII_v1.3" tilewidth="64" tileheight="64" tilecount="64" columns="8">
 <image source="../ProjectBackerman_Bach/core/assets/0x72_DungeonTilesetII_v1.3.png" width="512" height="512"/>
</tileset>
