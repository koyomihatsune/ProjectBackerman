<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="chort_idle_anim_f0" tilewidth="16" tileheight="24" tilecount="1" columns="1">
 <image source="chort_idle_anim_f0.png" width="16" height="24"/>
</tileset>
